#pragma once

void do_reboot();