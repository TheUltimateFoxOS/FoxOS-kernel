#pragma once

int sprintf(char *buf, const char *fmt, ...);
