#pragma once

extern "C" void init_procces();
void set_autoexec(char* path);
