#pragma once

void set_task_errno(int errno);