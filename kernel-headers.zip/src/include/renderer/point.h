#pragma once

namespace renderer {
	struct point_t{
		long x;
		long y;
	};
}