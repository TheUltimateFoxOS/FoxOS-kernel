#pragma once

unsigned int disassemble(unsigned char *bytes, unsigned int max, int offset, char *output);